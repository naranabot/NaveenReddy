package com.sg.sms.ui;

import java.util.ArrayList;
import java.util.Scanner;

import com.cg.sms.dto.Student;
import com.cg.sms.service.StudentService;
import com.cg.sms.service.StudentServiceImp1;

public class Main {

	public static void main(String[] args) {
		
		
		
		StudentService service = new StudentServiceImp1();
		Scanner sc = new Scanner(System.in);
		int ch = 0;
            
		do{
		
	System.out.println("1.  Add Student");
	System.out.println("2.  Display Student Details");
	System.out.println("3.  Update Details");
	System.out.println("4.  Display Student list");
	System.out.println("Enter your choice");
	ch = sc.nextInt();
	Student students;
	switch(ch) {
	
	case 1 :
	
		System.out.println(" Enter Name :");
        String name = sc.next();
        
        System.out.println("Enter Course NAme");
        String cname = sc.next();
        
        System.out.println("Enter Age");
      int age=sc.nextInt();
        
        System.out.println("enter mobile number");
        String mob = sc.next();
        
	
        Student student = new Student();
        
        student.setName(name);
        student.setCourseName(cname);
        student.setAge(age);
        student.setMobileno(mob);
        int rn = service.addStudent(student);
        System.out.println("student record added ..."+ rn);
        
        break;
        
	case 2 :
        System.out.println(" Enter Roll no ");
        rn=sc.nextInt();
        
        student = service.getStudent(rn);
        if(student==null)
        	 System.out.println("Record not found...");
        else{
        
        System.out.println(student.getName());
        System.out.println(student.getAge());
        System.out.println(student.getCourseName());
        System.out.println(student.getMobileno());
        }
        break;
        
	case 3:
		 System.out.println("Enter Rollno :");
		 rn = sc.nextInt();
		 
		 student = service.getStudent(rn);
		 if(student == null)
			 System.out.println("Record not found");
		 else{
	    System.out.println("Enter new mobile number :");
	    String mobno= sc.next();
	    student.setMobileno(mobno);
	    student = service.updateStudent(student);
	    System.out.println("Record updated");
	    
	    
	    System.out.println(student.getMobileno());
	    System.out.println(student.getName());
		 }
	    break;
	    
	case 4 :
		System.out.println("Enter Course name");
		cname = sc.next();
		ArrayList<Student> list = service.getStudentList(cname);
		if(list.size()==0)
			System.out.println("No student enrolled to this record");
		else {
			for(Student s : list){
				System.out.println(s.getName()+ s.getMobileno());
			}
		}
	    
	} // end of switch
		}while(ch!=5);
   //end of dowhile
		
}
}