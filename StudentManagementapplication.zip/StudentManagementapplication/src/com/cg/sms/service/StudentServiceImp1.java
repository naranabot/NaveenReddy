package com.cg.sms.service;

import java.util.ArrayList;

import com.cg.sms.dao.StudentDAO;
import com.cg.sms.dao.StudentDAOImp1;
import com.cg.sms.dto.Student;

public class StudentServiceImp1 implements StudentService {

	StudentDAO dao;
	public StudentServiceImp1(){
		
		dao = new StudentDAOImp1();
	}
	@Override
	public int addStudent(Student student) {

		int rn= dao.addStudent(student);
		return rn;
		

	}
	@Override
	public Student getStudent(int rn) {

		
		return dao.getStudent(rn);
		
		
	}
	@Override
	public Student updateStudent(Student student) {

		
		return dao.updateStudent(student);
	}
	@Override
	public ArrayList<Student> getStudentList(String coursename) {
		// TODO Auto-generated method stub
		return dao.getStudentList(coursename);
	}

}
