
package com.cg.mobshop.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import antlr.collections.List;

import com.cg.mobshop.dto.Mobile;
import com.cg.mobshop.dto.PurchaseDetails;
import com.cg.mobshop.exception.PurchaseException;

public class PurchaseDetailsDaoImpl  implements PurchaseDAO{

	EntityManager  manager;
	public PurchaseDetailsDaoImpl() throws PurchaseException{
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPA-PU");
		manager = emf.createEntityManager();
		
	}
	
	@Override
	public int addPurchaseDetails(PurchaseDetails pr) throws PurchaseException {

		manager.getTransaction().begin();
		manager.persist(pr);
		manager.getTransaction().commit();
		return pr.getPurchaseId();
		
		
	}
	@Override
	public ArrayList getMobileList() {
		ArrayList<Mobile> list= new ArrayList<>();
		
		TypedQuery<Mobile> qry = manager.createQuery("select p from Mobile p ", Mobile.class);  //here Mobile is entity
		list = (ArrayList<Mobile>) qry.getResultList();
		
		return  list;
	}
	
	@Override
	public List getMobileList(int min, int max) throws PurchaseException {
       TypedQuery<Mobile> qry = manager.createQuery("select p from mobile p "+" where p.price between :lower and :upper ", Mobile.class);
		qry.setParameter("lower",min);
		qry.setParameter("upper",max);
		
		ArrayList<Mobile> list = (ArrayList<Mobile>) qry.getResultList();
		
		return (List) list;
	}

	@Override
	public Mobile updateMobileDetails(Mobile mob) {
		
		manager.getTransaction().begin();
		Mobile mobile = manager.find(Mobile.class, mob.getMobileId());
				mobile.setPrice(mob.getPrice());
				mobile.setQuantity(mob.getQuantity());
				manager.merge(mobile);
				manager.getTransaction().commit();
		return mob;
	}

	
}











