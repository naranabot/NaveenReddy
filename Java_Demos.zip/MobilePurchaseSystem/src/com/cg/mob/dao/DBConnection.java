package com.cg.mob.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.cg.mob.exception.PurchaseException;

public class DBConnection {
	
	
	public static Connection con;
	public static Connection getConnection() throws PurchaseException {
		
		
		
		String url = "jdbc:oracle:thin:@10.51.103.201:1521:orcl11g" ;
		String username = "lab2etrg1";
		String pwd = "lab2eoracle";
		
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			System.out.println("Class loaded..");
			con = DriverManager.getConnection(url, username, pwd);
			System.out.println("Connected to db...");
			
		}catch (SQLException e){
			throw new PurchaseException(e.getMessage());
		}catch (ClassNotFoundException e) {
			throw new PurchaseException(e.getMessage());
		}
	
		return con;
	}
	public static void main(String[] args) {
		
		try{
			getConnection();
		}catch (PurchaseException e) {
			e.printStackTrace();
		}
	}

}
