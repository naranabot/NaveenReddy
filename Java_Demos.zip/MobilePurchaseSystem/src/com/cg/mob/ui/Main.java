package com.cg.mob.ui;

import java.util.ArrayList;
import java.util.Scanner;

import com.cg.mob.dto.Mobile;
import com.cg.mob.dto.PurchaseDetails;
import com.cg.mob.exception.PurchaseException;
import com.cg.mob.service.PurchaseService;
import com.cg.mob.service.PurchaseServiceImpl;

public class Main {
	
	private static Scanner sc;
	

	public static void main(String[] args)  throws PurchaseException {
		
		

		PurchaseService service = new PurchaseServiceImpl();
		Scanner sc = new Scanner(System.in);
		int ch=0;
		
		do{
			System.out.println("Welcome to hhfs");
           ch = sc.nextInt();
           switch(ch)
           {
           
          /* case 1:
        	System.out.println("  enter customer name");
   			String name = sc.next();
   			System.out.println(" enter mobile number");
   			String phn = sc.next();
   			System.out.println("  mobile mail Id");
   			String mail = sc.next();
   			System.out.println("  enter mobile Id");
   			int mb = sc.nextInt();
           
          PurchaseDetails pr = new PurchaseDetails();
          pr.setCustName(name);
          pr.setPhoneNo(phn);
          pr.setMailId(mail);
          pr.setMobileId(mb);
          int pi = service.addPurchasedetails(pr);
          System.out.println("Purchase details added..."+pi);*/
        
          
          
        	/*   
        	 * case 2
        	   ArrayList<Mobile> list = service.getMobileList();
        	   if(list.size()==0){
        		   System.out.println("No record found");
        	   }
        	   else{
        		   for(Mobile mob : list){
        			   System.out.print(mob.getMobileId()+"\t ");
        			  
        			   System.out.print(mob.getQuantity()+"\t ");
        			   System.out.print(mob.getPrice()+"\t");
        			   System.out.print(mob.getName()+"\n");
        		   }
        	   }*/
           
           case 3 : 
        	   System.out.println("  enter Mobile Id : ");
      			int mobid = sc.nextInt();
      			System.out.println(" enter price");
      			double pr = sc.nextDouble();
      			System.out.println(" Enter quantity");
      			int quantity = sc.nextInt();
      			
      			Mobile mobile = new Mobile();
      			mobile.setMobileId(mobid);
      			mobile.setPrice(pr);        	   
        	   mobile.setQuantity(quantity);
        	   
        	   mobile = service.updateMobileDetails(mobile);
              if(mobile!=null) 
             System.out.println("Mobile details updated successfully");  
           }	
		}while(ch!=5);
	}

}
