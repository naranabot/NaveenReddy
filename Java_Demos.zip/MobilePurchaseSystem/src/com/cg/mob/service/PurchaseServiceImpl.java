package com.cg.mob.service;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.mob.dao.PurchaseDAO;
import com.cg.mob.dao.PurchaseDAOImpl;
import com.cg.mob.dto.Mobile;
import com.cg.mob.dto.PurchaseDetails;
import com.cg.mob.exception.PurchaseException;

public class PurchaseServiceImpl implements PurchaseService{

	
	PurchaseDAO dao;
	public PurchaseServiceImpl(){
		try{
			dao = new PurchaseDAOImpl();
		
		}catch (PurchaseException e){
			e.printStackTrace();
		}
	}
	
	
	@Override
	public int addPurchasedetails(PurchaseDetails pr) {
		
		
		return dao.addPurchaseDetails(pr);
	}

	@Override
	public ArrayList<Mobile> getMobileList() {
		
		return dao.getMobileList();
	}

	@Override
	public ArrayList<Mobile> getMobileList(int min, int max) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Mobile updateMobileDetails(Mobile mob) {
		// TODO Auto-generated method stub
		return dao.updateMobileDetails(mob);
	}


	@Override
	public PurchaseDetails validateDetails(PurchaseDetails pd) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public boolean ValidateName(String name) {

		Pattern pat = Pattern.compile("[A-Z][a-z]{3,12}");
		Matcher mat = pat.matcher(name);
		return mat.matches();
	}


	@Override
	public boolean ValidatePhoneNo(String mob) {

		Pattern pat = Pattern.compile("[1-9][0-9]{9}");
		Matcher mat = pat.matcher(mob);
				
			return mat.matches();
	}


	@Override
	public boolean ValidateEmail(String email) {
		Pattern pat = Pattern.compile("[A-Za-z0-9]{2,15}@capgemini.com");
		Matcher mat = pat.matcher(mob);
				
			return mat.matches();
	}

	
	

}
