package com.cg.mob.service;

import java.util.ArrayList;

import com.cg.mob.dto.Mobile;
import com.cg.mob.dto.PurchaseDetails;
import com.cg.mob.exception.PurchaseException;

public interface PurchaseService {
	public int addPurchasedetails(PurchaseDetails pr);
	public ArrayList<Mobile> getMobileList();
	public ArrayList<Mobile> getMobileList(int min,int max);
	public Mobile updateMobileDetails(Mobile mob);

	public PurchaseDetails validateDetails(PurchaseDetails pd) throws PurchaseException;
	public boolean ValidateName(String name);
	public boolean ValidatePhoneNo(String mob);
	public boolean ValidateEmail(String email);

}
